package com.example.myapplication

object API_KEY {
    const val MY_API_KEY = "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"
}