package com.example.myapplication

data class Message(
    val authorId: String = "",
    val content: String = "",
    val timestamp: Long = 0L
)


