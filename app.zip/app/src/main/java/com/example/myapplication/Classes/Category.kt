package com.example.myapplication.Classes

data class Category( var fame: String? = null
)
