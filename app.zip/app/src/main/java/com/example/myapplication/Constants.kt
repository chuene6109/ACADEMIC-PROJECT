package com.example.myapplication

object Constants {

    const val MAX_BTYES_PDF: Long = 50000000 //50MB

}